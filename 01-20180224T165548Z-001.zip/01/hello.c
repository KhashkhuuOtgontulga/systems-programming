#include <stdio.h>

void say_hello_to(char *to_greet) {
  printf("Hello %s!\n", to_greet);
}
